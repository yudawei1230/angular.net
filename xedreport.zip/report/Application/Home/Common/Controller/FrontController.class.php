<?php
namespace Admin\Common\Controller;
use Think\Controller;
 //父类
class FuController extends Controller {
}